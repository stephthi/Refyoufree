class AddQuestionsToDocumentations < ActiveRecord::Migration
  def change
  	add_column :documentations, :one, :string
		add_column :documentations, :two, :string
		add_column :documentations, :three, :string
		add_column :documentations, :four, :string
		add_column :documentations, :five, :string
		add_column :documentations, :six, :string
		add_column :documentations, :seven, :string
		add_column :documentations, :eight, :string
		add_column :documentations, :nine, :string
		add_column :documentations, :ten, :string
		add_column :documentations, :eleven, :string
		add_column :documentations, :twelve, :string
		add_column :documentations, :thirteen, :string
		add_column :documentations, :fourteen, :string
		add_column :documentations, :fifteen, :string
		add_column :documentations, :xixteen, :string
		add_column :documentations, :seventeen, :string
		add_column :documentations, :eighteen, :string
		add_column :documentations, :nineteen, :string
		add_column :documentations, :twenty, :string
  end
end
