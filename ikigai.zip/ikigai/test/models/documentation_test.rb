require 'test_helper'

class DocumentationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
