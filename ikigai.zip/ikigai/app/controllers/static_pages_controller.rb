class StaticPagesController < ApplicationController
	def home
	end

	def faq
	end
end
