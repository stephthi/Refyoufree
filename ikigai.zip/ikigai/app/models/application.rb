class Application < ActiveRecord::Base

end
